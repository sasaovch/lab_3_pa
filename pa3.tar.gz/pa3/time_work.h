#pragma once

#include "ipc.h"

void sync_lamport_time(void *__info, timestamp_t t);

#include "pipes_const.h"
#include "ipc.h"
#include "pa2345.h"
#include "banking.h"


FILE *elf;
FILE *plf;

Info pipe_info;

int pm[10][10][2];

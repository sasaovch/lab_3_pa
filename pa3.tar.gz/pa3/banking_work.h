#pragma once

#include "banking.h"

void transfer(void * parent_data, local_id src, local_id dst, balance_t amount);
